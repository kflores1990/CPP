#include "CharInfo.h"
